answers = [ 'd', 'c', 'd', 'd', 'd' ]
n = int(input())
print(answers[n-1].lower())
