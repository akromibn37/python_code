answers = [ 'a', 'b', 'e', 'd', 'd' ]
n = int(input())
print(answers[n-1].lower())