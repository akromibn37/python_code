a = [e for e in input().split()]
k = [int(e) for e in input().split()]
b = [a[e] for e in k]
print(" ".join(b))
