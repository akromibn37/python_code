d = [int(e) for e in input().split()]
print(x[-2]+x[-2]-x[-4])
