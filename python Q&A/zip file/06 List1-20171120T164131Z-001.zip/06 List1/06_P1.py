a = []
while True:
    x = int(input())
    if x < 0 : break
    a.append(x)
for i in a:
    print(i+x)
