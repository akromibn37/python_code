n = int(input())
data = [int(e) for e in input().split()]
print(sum(data)/n)

