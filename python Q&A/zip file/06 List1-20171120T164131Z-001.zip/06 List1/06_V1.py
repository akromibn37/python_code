a1 = 'x'
a2 = 'k'
a3 = 'tu'
a4 = 'c'
a5 = 'h'
answers = [ a1, a2, a3, a4, a5 ]
n = int(input())
print(answers[n-1].lower())
