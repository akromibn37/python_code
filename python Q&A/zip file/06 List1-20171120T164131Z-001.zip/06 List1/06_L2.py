x = [int(e) for e in input().split()]
y = [e%2 for e in x]
print(y)
print(sum(y))
