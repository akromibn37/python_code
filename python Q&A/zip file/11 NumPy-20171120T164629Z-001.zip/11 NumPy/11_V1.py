answers = [ 'd', 'b', 'd', 'a', 'd' ]
n = int(input())
print(answers[n-1].lower())