print("Hello World")
print("Bye Java")
print("Hello Python")
print("4+5 = 9")
