print("5b4fc6fc15")
print("23eeeb4347")
