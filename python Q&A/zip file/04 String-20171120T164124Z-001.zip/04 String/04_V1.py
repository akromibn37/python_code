answers = [ 'b', 'd', 'c', 'c', 'b' ]
n = int(input())
print(answers[n-1].lower())