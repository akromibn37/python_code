chars = input().strip()
n = 0
for c in chars:
    if "A" <= c <= "Z" : n += 1
print(n)
