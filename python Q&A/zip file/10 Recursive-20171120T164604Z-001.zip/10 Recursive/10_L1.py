answers = [ 'CE', 'AB', 'H', 'J', 'DHJMN'  ]
n = int(input())
print(''.join(sorted(answers[n-1].upper())))
