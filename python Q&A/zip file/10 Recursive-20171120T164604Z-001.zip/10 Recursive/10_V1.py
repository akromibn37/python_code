d=['c','h','m','c','g','q','a','h','k','c','e','g']
print(d[int(input())-1])

