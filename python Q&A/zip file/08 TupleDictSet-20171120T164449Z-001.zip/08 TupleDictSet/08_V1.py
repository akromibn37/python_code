answers = [ 'c', 'e', 'e', 'd', 'c' ]
n = int(input())
print(answers[n-1].lower())
