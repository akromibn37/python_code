answers = [ 'd', 'a', 'a', 'e', 'a' ] 
n = int(input()) 
print(answers[n-1].lower())
