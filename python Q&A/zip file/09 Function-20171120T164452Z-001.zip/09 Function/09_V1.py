answers = [ 'a', 'd', 'j', 'a', 'p', 'e', 'g', 'e', 'e', 'b' ]
n = int(input())
print(answers[n-1].lower())
