a1 = 'j'
a2 = 'k'
a3 = 'g'
a4 = 'tu'
a5 = 'n'
answers = [ a1, a2, a3, a4, a5 ]
n = int(input())
print(answers[n-1].lower())
