answers = [ 'd', 'a', 'd', 'b', 'e' ]
n = int(input())
print(answers[n-1].lower())
