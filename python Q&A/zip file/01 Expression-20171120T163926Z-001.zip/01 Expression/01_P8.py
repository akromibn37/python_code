w = float(input())
h = float(input())
print( w/((h/100)**2) )
