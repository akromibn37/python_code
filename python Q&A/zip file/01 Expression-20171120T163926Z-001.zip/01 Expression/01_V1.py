answers = [ 'e', 'b', 'e', 'b', 'b' ]
n = int(input())
print(answers[n-1].lower())
