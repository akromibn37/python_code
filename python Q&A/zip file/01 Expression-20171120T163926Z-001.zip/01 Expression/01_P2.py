r = float(input())
print(3.14159*r*r)
