answers = [ 'b', 'e', 'e', 'b', 'd' ]
n = int(input())
print(answers[n-1].lower())
