x = float(input())
t1 = x
t2 = x**2/2
t3 = x**3/6
t4 = x**4/24
f = 1 + t1 + t2 + t3 + t4
print(t2)
print(t3)
print(t4)
print(f)
