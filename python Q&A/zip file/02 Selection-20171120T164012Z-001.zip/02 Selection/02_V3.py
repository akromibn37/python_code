d = float(input())
max = d
min = d
d = float(input())
if d>max:
    max = d
if d<min:
    min = d
d = float(input())
if d>max:
    max = d
if d<min:
    min = d
d = float(input())
if d>max:
    max = d
if d<min:
    min = d
d = float(input())
if d>max:
    max = d
if d<min:
    min = d
d = float(input())
if d>max:
    max = d
if d<min:
    min = d
print(min,max)
