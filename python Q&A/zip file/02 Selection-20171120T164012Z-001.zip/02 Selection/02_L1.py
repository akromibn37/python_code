answers = [ 'e', 'd', 'c', 'b', 'e' ]
n = int(input())
print(answers[n-1].lower())
