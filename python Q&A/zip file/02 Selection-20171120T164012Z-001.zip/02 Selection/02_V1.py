answers = [ 'a', 'e', 'e', 'b', 'c' ]
n = int(input())
print(answers[n-1].lower())
