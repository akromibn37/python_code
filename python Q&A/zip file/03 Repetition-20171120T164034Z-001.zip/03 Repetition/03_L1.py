a1 = 'a'
a2 = 'v'
a3 = 'n'
a4 = 'p'
a5 = 'efghijklmv'
answers = [ a1, a2, a3, a4, a5 ]
n = int(input())
print(answers[n-1].lower())
