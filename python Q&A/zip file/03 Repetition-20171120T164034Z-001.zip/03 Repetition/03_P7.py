n,f = [int(x) for x in input().split()]
c = 0
for i in range(n):
    x = int(input())
    if x == f :
        c += 1
print(c)
