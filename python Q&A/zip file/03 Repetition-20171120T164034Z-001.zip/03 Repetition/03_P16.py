x = int(input())
y = int(input())
for k in range(1,y+1):
    print(x, k, x*k)
