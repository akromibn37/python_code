a1 = 'a'
a2 = 'p'
a3 = 'j'
a4 = 'abcd'
a5 = 'm'
answers = [ a1, a2, a3, a4, a5 ]
n = int(input())
print(answers[n-1].lower())
